<script src="<?php echo base_url();?>js/jquery.js.js"></script>
<script src="<?php echo base_url();?>js/bootstrap.min.js"></script>




 </body>
 </html>