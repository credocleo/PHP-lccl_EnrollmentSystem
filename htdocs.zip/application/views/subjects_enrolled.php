 <html>
	<head>
 		<meta charset="utf-8">
 		<meta name="viewport" content="width=device-width, initial-scale=1.0">
 		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="css/query-ul.min.css" rel="stylesheet">
		
		<div id ="student_information_header">
    </head>

<body>	

<form>
			<div class="col-md-6 col-md-offset-3">
					<table border ="0" cellpadding="">
						<tr>
							<td colspan = "2">
								<div class="form-group">
									<label for="studentNo">Student ID No.</label>
									<input class="form-control" id="studentIDno" name="student_idnum" type="text" value="" size="30" aria-required="true" required="required" placeholder ="Student Id No.">
								</div>
							</td> 
						</tr>
							
						<tr>
							<td>
								<div class="form-group">
									<label for="LastName">Last Name</label>
									<input class="form-control" id="LastName" name="student_last_name" type="text" value="" size="30" aria-required="true" required="required" placeholder="Last Name">
								</div>
							</td>
							
							<td>
								<div class="form-group">
									<label for="FirstName">First Name</label>
									<input class="form-control" id="FirstName" name="student_first_name" type="text" value="" size="30" aria-required="true" required="required" placeholder="First Name">
								</div>
							</td>
							
							
							<td>
								<div class="form-group">
									<label for="MiddleName">Middle Name</label>
									<input class="form-control" id="MiddleName" name="middle_name" type="text" value="" size="30" aria-required="true" required="required" placeholder="Middle Name">
								</div>
							</td>
						</tr>
								
						<tr>
							<td colspan="3">
								<div class="form-group">
									<label for="MiddleName">Course</label>
									<input class="form-control" id="Course" name="Course" type="text" value="" size="30" aria-required="true" required="required" placeholder="Course">
								</div> 
							</td>
						</tr>
							
						<tr>	
							<td>
								<div class="form-group">
									<label for="LastName">Year Level</label>
									<input class="form-control" id="Year" name="Year" type="text" value="" size="30" aria-required="true" required="required" placeholder="Year">
								</div>
							</td>
							
							<td>
								<div class="form-group">
									<label for="FirstName">Semester</label>
									<input class="form-control" id="Semester" name="Semester" type="text" value="" size="30" aria-required="true" required="required" placeholder="Semester">
								</div>
							</td>
							
							
							<td>
								<div class="form-group">
									<label for="MiddleName">Major</label>
									<input class="form-control" id="academic_year" name="academic_year" type="text" value="" size="30" aria-required="true" required="required" placeholder="Academic Year">
								</div>
							</td>
						</tr>
							
						<tr>
							<td>
								<div class="form-group">
									<label for="MiddleName">Gender:</label></br>
									<input type="radio" value="Male" name="gender">Male</br>
									<input type="radio" value="Female" name="gender">Female
								</div>
							</td>
							
							<td>
								<div class="form-group">
									<label for="MiddleName">Classification:</label></br>
									<input type="checkbox" name="old" value="old" checked>Old</br>
									<input type="checkbox" name="new" value="new">New
								</div>
							</td>
						</tr>
					</table>
					
</br></br>
		<table class="table table-bordered">
		
     <tr>
		<th>Subject Code</th>
		<td>Course No.</td>
		<td>Course Description</td>
		<td>Units</td>
		<td>Days</td>
		<td>Time</td>
		<td>Room</td>
	</tr>
  
	<tr>
		<th></th>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	
	<tr>
		<th></th>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	
	<tr>
		<th></th>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	
	<tr>
		<th></th>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	
	<tr>
		<th></th>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	
	<tr>
		<th></th>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	
	<tr>
		<th></th>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	
	<tr>
		<th></th>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	
	<tr>
		<th></th>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	
	<tr>
		<th></th>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	
	<tr>
		<th></th>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	
	
  
	
</table>
</div>

<script src="js/jquery.js.js"></script>
<script src="js/bootstrap.min.js"></script>




 </body>
 </html>
