<body>
	
			<div class="col-md-6 col-md-offset-3">

	<table border=1>
	<table border ="0" cellpadding="">


				<h3>PERSONAL INFORMATION</h3>
			<tr>
				<td colspan = "2">
					<div class="form-group">
						<label for="student_id_number">Student ID No.</label>
						<?php echo $query["student_id_number"];?>
					</div> 
				</td>								
			</tr>
		
			<tr>
				<td>
					<div class="form-group">
						<label for="student_last_name">Last Name</label>
						<?php echo $query["student_last_name"];?>
				</td>

				<td>
					<div class="form-group">
						<label for="student_first_name">First Name</label>
						<?php echo $query["student_first_name"];?>
					</div>
				</td>
			
				<td>
					<div class="form-group">
						<label for="middle_name">Middle Name</label>
						<?php echo $query["middle_name"];?>
					</div> 
				</td>
			</tr>
				
			<tr>
				<td>
					<div class="form-group">
						<label for="birth_date">Date of Birth</label>
						<?php echo $query["birth_date"];?>
					</div>
				</td> 
			
				<td>
					<div class="form-group">
						<label for="place_of_birth">Place of Birth</label>
						<?php echo $query["place_of_birth"];?>
					</div>
				</td>
				
				<td>
					<div class="form-group">
						<label for="contact_no">Contact No.</label>
						<?php echo $query["contact_no"];?>
					</div>
				</td>
			</tr>
			
			<tr> 
				<td colspan="2">
					<div class="form-group">
						<label for="home_address">Home Adress</label>
						<?php echo $query["home_address"];?>
					</div>
				</td>
			
				<td>
					<div class="form-group">
						<label for="home_tellno">Tell./Cell</label>
						<?php echo $query["home_tellno"];?>
					</div>
				</td>
			</tr>
			
			<tr>
				<td colspan="2">
					<div class="form-group">
						<label for="city_address">City Address</label>
						<?php echo $query["city_address"];?>
					</div> 
				</td>
			
				<td>
					<div class="form-group">
						<label for="cell_no">Tell./Cell</label>
						<?php echo $query["cell_no"];?>
					</div>
				</td>
			</tr>
			
			<tr>
				<td colspan="2">
					<div class="form-group">
						<label for="boarding_address">Boarding Address</label>
						<?php echo $query["boarding_address"];?>
					</div> 
				</td>
			
				<td>
					<div class="form-group">
						<label for="boarding_cel_no">Tell./Cell</label>
						<?php echo $query["boarding_cel_no"];?>
					</div>
				</td>
			</tr>
			
			<tr>
				<td colspan="2">
					<div class="form-group">
						<label for="provincial_address">Provincial Address</label>
						<?php echo $query["provincial_address"];?>
					</div> 
				</td>
			
				<td>
					<div class="form-group">
						<label for="provincial_tel_no">Tell./Cell</label>
						<?php echo $query["provincial_tel_no"];?>
					</div>
				</td>
			</tr>
			
			<tr>
				<td colspan="2">
					<div class="form-group">
						<label for="email_address">Email Address</label>
						<?php echo $query["email_address"];?>
					</div> 
				</td>
			</tr>

			<tr>
				<td colspan="1">
					<div class="form-group">
						<label for="nationality">Nationality</label>
						<?php echo $query["nationality"];?>
				</td>
			
				<td>
					<div class="form-group">
						<label for="religion">Religion</label>
						<?php echo $query["religion"];?>
					</div>
				</td>
				
				
				<td>
					<div class="form-group">
						 <label for="civil_status">Civil Status</label>
						 	<?php echo $query["civil_status"];?>
						</select>
					</div>
				</td>
			</tr>
			
			<tr>	
				<td colspan="1">
				
					<div class="form-group">
						<label for="gender">Gender:</label>
						<?php echo $query["gender"];?>
					</div> 
				</td>
			</tr>
			
			<tr>
				<td colspan="3">
					<div class="form-group"></label>
						<label for="name_of_spouse_if_married">Name of Spouse(if Married)</label>
						<?php echo $query["name_of_spouse_if_married"];?>
					</div>
				</td>
			</tr>
			

			<tr>
				<td colspan="3">
					<div class="form-group">
						<label for="name_of_employer_if_working">Name of Employer, if working </label>
						<?php echo $query["name_of_employer_if_working"];?>
					</div>
				</td>
			</tr>
			
			<tr>
				<td colspan="2">
					<div class="form-group">
						<label for="employer_address">Address</label>
						<?php echo $query["employer_address"];?>
					</div>
			
				<td>
					<div class="form-group">
						<label for="employer_cel_no">Tell./Cell</label>
						<?php echo $query["employer_cel_no"];?>
						
					</div>
				</td>
			</tr>
			
			<tr>
				<td colspan="3">
					<h3>FAMILY BACKGROUND</h3>
				</td>
			</tr>
			
			<tr>
				<td colspan="2">
					<div class="form-group">
						<label for="fathers_name">Father`s Name</label>
						<?php echo $query["fathers_name"];?>
					</div>
				</td>
			
				<td>
					<div class="form-group">
						<label for="fathers_occupation">Occupation</label>
						<?php echo $query["fathers_occupation"];?>
					</div>
				</td>
			</tr>
			
			
			<tr>
				<td colspan="3">
					<div class="form-group">
						<label for="father_educ_attainment">Educational Attainment</label>
						<?php echo $query["father_educ_attainment"];?>
					</div>
				<td>
			</tr>
			
			<tr>
				<td colspan="2">
					<div class="form-group">
						<label for="mothers_name">Mother`s Name</label>
						<?php echo $query["mothers_name"];?>
					</div>
				</td>
			
				<td>
					<div class="form-group">
						<label for="mothers_occupation">Occupation</label>
						<?php echo $query["mothers_occupation"];?>
					</div>
				</td>
			</tr>
			
			<tr>
				<td colspan="3">
					<div class="form-group">
						<label for="mother_educ_attainment">Educational Attainment</label>
						<?php echo $query["mother_educ_attainment"];?>
					</div>
				<td>
			</tr>
			
			<tr>
				<td colspan="2">
					<div class="form-group">
						<label for="guardians_name">Guardian`s Name</label>
						<?php echo $query["guardians_name"];?>
					</div>
				</td>
				
				<td>
					<div class="form-group">
						<label for="guardian_occupation">Occupation</label>
						<?php echo $query["guardian_occupation"];?>
					</div>
				</td>
			</tr>
			
			<tr>
				<td colspan="2">
					<div class="form-group">
						<label for="guardians_address">Address</label>
						<?php echo $query["guardians_address"];?>
					</div>
				</td>
			
				<td>
					<div class="form-group">
						<label for="guardians_cel_no">Tell./Cell</label>
						<?php echo $query["guardians_cel_no"];?>
					</div>
				</td>
			</tr>
			
			<tr>
				<td colspan="3">
					<div class="form-group">
						<label for="guardian_educ_attainment">Educational Attainment</label>
						<?php echo $query["guardian_educ_attainment"];?>
					</div>
				</td>
			</tr>
			
			<tr>
				<td colspan="2">
					<div class="form-group">
						<label for="guardian_relationship">Relationship to Guardian</label>
						<?php echo $query["guardian_relationship"];?>
					</div>
				</td>
			</tr>
			
			<tr>
				<td colspan="3">
					<div class="form-group">
						<label for="grades_to_be_sent_to">Grades to be Sent To</label>
						<?php echo $query["grades_to_be_sent_to"];?>
					</div>
				</td>
			</tr>
			
			<tr>
				<td colspan="2">
					<div class="form-group">
						<label for="grades_to_sent_address">Address</label>
						<?php echo $query["grades_to_sent_address"];?>
					</div>
				</td>
			
				<td>
					<div class="form-group">
						<label for="grades_cel_no">Tell./Cell</label>
						<?php echo $query["grades_cel_no"];?>
					</div>
				</td>
			</tr>

			<tr>
				<td colspan="3">
					<h3>EDUCATIONAL BACKGROUND </h3>
				</td>
			</tr>
			
			<tr>
				<td colspan="2">
					<div class="form-group">
						<label for="elementary">Elementary</label>
						<?php echo $query["elementary"];?>
					</div>
				</td>
			
				<td>
					<div class="form-group">
						<label for="elementary_sy">School Year</label>
						<?php echo $query["elementary_sy"];?>
					</div>
				</td>
			</tr>
			
			<tr>
				<td colspan="3">
					<div class="form-group">
						<label for="elementary_address">Address</label>
						<?php echo $query["elementary_address"];?>
					</div>
				</td>
			</tr>
			
			<tr>
				<td colspan="2">
					<div class="form-group">
						<label for="high_school">High School</label>
						<?php echo $query["high_school"];?>
					</div>
				</td>
			
				<td>
					<div class="form-group">
						<label for="high_school_sy">School Year</label>
						<?php echo $query["high_school_sy"];?>
					</div>
				</td>
			<tr>
			
			<tr>
				<td colspan="3">
					<div class="form-group">
						<label for="high_school_address">Address</label>
						<?php echo $query["high_school_address"];?>
					</div>
				</td>
			</tr>
			
			<tr>
				<td colspan="2">
					<div class="form-group">
						<label for="college">School Last Attended: College</label>
						<?php echo $query["college"];?>
					</div>
				</td>
			
				<td>
					<div class="form-group">
						<label for="college_sy">School Year</label>
						<?php echo $query["college_sy"];?>
					</div>
				</td>
			<tr>
			
			<tr>
				<td colspan="3">
					<div class="form-group">
						<label for="college_address">Address</label>
						<?php echo $query["college_address"];?>
					</div>
				</td>
			</tr>
			
								
			<tr>
				<td>
					<button type="submit" name = "submit" class="btn btn-primary" id="submit" onClick='return checkname()'>Submit</button>
				</td>
				
				<td colspan="2">
					<button type="reset" class="btn btn-primary" id="clear" value="reset">Clear</button>
				</td>
			</tr>
		</table>
	<?php form_close();?>
</div>
</body>
</html>