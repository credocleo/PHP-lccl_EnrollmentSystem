
  <body>
   <div class="col-md-6 col-md-offset-3">
 
    <h4>Students Records</h4>
    <table>
     <tr>
      <td><strong>ID Number</strong></td>
      <td><strong>Last Name</strong></td>
      <td><strong>First Name</strong></td>
      <td><strong>Middle Name</strong></td>
    </tr> 
     <?php foreach($posts as $post){?>
     <tr>
         <td><?php echo $post->student_id_number;?></td>
         <td><?php echo $post->student_last_name;?></td>
         <td><?php echo $post->student_first_name;?></td>
         <td><?php echo $post->middle_name;?></td>
      </tr>     
     <?php }?>  
   </table>
 
 
  </body>
