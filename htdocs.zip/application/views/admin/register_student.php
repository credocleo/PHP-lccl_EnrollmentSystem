 <body>

  <!-- container section start -->
  <section id="container" class="">
      <!--header start-->
      <header class="header dark-bg">
            <div class="toggle-nav">
                <div class="icon-reorder tooltips" data-original-title="Toggle Navigation" data-placement="bottom"><i class="icon_menu"></i></div>
            </div>

            <!--logo start-->
            <a href="index.html" class="logo">Nice <span class="lite">Admin</span></a>
            <!--logo end-->

            <div class="nav search-row" id="top_menu">
                <!--  search form start -->
                <ul class="nav top-menu">                    
                    <li>
                        <form class="navbar-form">
                            <input class="form-control" placeholder="Search" type="text">
                        </form>
                    </li>                    
                </ul>
                <!--  search form end -->                
            </div>

            <div class="top-nav notification-row">                
                <!-- notificatoin dropdown start-->
                <ul class="nav pull-right top-menu">
                    
                    <!-- task notificatoin start -->
                    <li id="task_notificatoin_bar" class="dropdown">
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <span class="icon-task-l"></i>
                            <span class="badge bg-important">5</span>
                        </a>
                        <ul class="dropdown-menu extended tasks-bar">
                            <div class="notify-arrow notify-arrow-blue"></div>
                            <li>
                                <p class="blue">You have 5 pending tasks</p>
                            </li>
                            <li>
                                <a href="#">
                                    <div class="task-info">
                                        <div class="desc">Design PSD </div>
                                        <div class="percent">90%</div>
                                    </div>
                                    <div class="progress progress-striped">
                                        <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100" style="width: 90%">
                                            <span class="sr-only">90% Complete (success)</span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <div class="task-info">
                                        <div class="desc">
                                            Project 1
                                        </div>
                                        <div class="percent">30%</div>
                                    </div>
                                    <div class="progress progress-striped">
                                        <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100" style="width: 30%">
                                            <span class="sr-only">30% Complete (warning)</span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <div class="task-info">
                                        <div class="desc">Digital Marketing</div>
                                        <div class="percent">80%</div>
                                    </div>
                                    <div class="progress progress-striped">
                                        <div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: 80%">
                                            <span class="sr-only">80% Complete</span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <div class="task-info">
                                        <div class="desc">Logo Designing</div>
                                        <div class="percent">78%</div>
                                    </div>
                                    <div class="progress progress-striped">
                                        <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="78" aria-valuemin="0" aria-valuemax="100" style="width: 78%">
                                            <span class="sr-only">78% Complete (danger)</span>
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <div class="task-info">
                                        <div class="desc">Mobile App</div>
                                        <div class="percent">50%</div>
                                    </div>
                                    <div class="progress progress-striped active">
                                        <div class="progress-bar"  role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width: 50%">
                                            <span class="sr-only">50% Complete</span>
                                        </div>
                                    </div>

                                </a>
                            </li>
                            <li class="external">
                                <a href="#">See All Tasks</a>
                            </li>
                        </ul>
                    </li>
                    <!-- task notificatoin end -->
                    <!-- inbox notificatoin start-->
                    <li id="mail_notificatoin_bar" class="dropdown">
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <i class="icon-envelope-l"></i>
                            <span class="badge bg-important">5</span>
                        </a>
                        <ul class="dropdown-menu extended inbox">
                            <div class="notify-arrow notify-arrow-blue"></div>
                            <li>
                                <p class="blue">You have 5 new messages</p>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="photo"><img alt="avatar" src="./img/avatar-mini.jpg"></span>
                                    <span class="subject">
                                    <span class="from">Greg  Martin</span>
                                    <span class="time">1 min</span>
                                    </span>
                                    <span class="message">
                                        I really like this admin panel.
                                    </span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="photo"><img alt="avatar" src="./img/avatar-mini2.jpg"></span>
                                    <span class="subject">
                                    <span class="from">Bob   Mckenzie</span>
                                    <span class="time">5 mins</span>
                                    </span>
                                    <span class="message">
                                     Hi, What is next project plan?
                                    </span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="photo"><img alt="avatar" src="./img/avatar-mini3.jpg"></span>
                                    <span class="subject">
                                    <span class="from">Phillip   Park</span>
                                    <span class="time">2 hrs</span>
                                    </span>
                                    <span class="message">
                                        I am like to buy this Admin Template.
                                    </span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="photo"><img alt="avatar" src="./img/avatar-mini4.jpg"></span>
                                    <span class="subject">
                                    <span class="from">Ray   Munoz</span>
                                    <span class="time">1 day</span>
                                    </span>
                                    <span class="message">
                                        Icon fonts are great.
                                    </span>
                                </a>
                            </li>
                            <li>
                                <a href="#">See all messages</a>
                            </li>
                        </ul>
                    </li>
                    <!-- inbox notificatoin end -->
                    <!-- alert notification start-->
                    <li id="alert_notificatoin_bar" class="dropdown">
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">

                            <i class="icon-bell-l"></i>
                            <span class="badge bg-important">7</span>
                        </a>
                        <ul class="dropdown-menu extended notification">
                            <div class="notify-arrow notify-arrow-blue"></div>
                            <li>
                                <p class="blue">You have 4 new notifications</p>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="label label-primary"><i class="icon_profile"></i></span> 
                                    Friend Request
                                    <span class="small italic pull-right">5 mins</span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="label label-warning"><i class="icon_pin"></i></span>  
                                    John location.
                                    <span class="small italic pull-right">50 mins</span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="label label-danger"><i class="icon_book_alt"></i></span> 
                                    Project 3 Completed.
                                    <span class="small italic pull-right">1 hr</span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <span class="label label-success"><i class="icon_like"></i></span> 
                                    Mick appreciated your work.
                                    <span class="small italic pull-right"> Today</span>
                                </a>
                            </li>                            
                            <li>
                                <a href="#">See all notifications</a>
                            </li>
                        </ul>
                    </li>
                    <!-- alert notification end-->
                    <!-- user login dropdown start-->
                    <li class="dropdown">
                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <span class="profile-ava">
                                <img alt="" src="img/avatar1_small.jpg">
                            </span>
                            <span class="username">Jenifer Smith</span>
                            <b class="caret"></b>
                        </a>
                        <ul class="dropdown-menu extended logout">
                            <div class="log-arrow-up"></div>
                            <li class="eborder-top">
                                <a href="#"><i class="icon_profile"></i> My Profile</a>
                            </li>
                            <li>
                                <a href="#"><i class="icon_mail_alt"></i> My Inbox</a>
                            </li>
                            <li>
                                <a href="#"><i class="icon_clock_alt"></i> Timeline</a>
                            </li>
                            <li>
                                <a href="#"><i class="icon_chat_alt"></i> Chats</a>
                            </li>
                            <li>
                                <a href="login.html"><i class="icon_key_alt"></i> Log Out</a>
                            </li>
                            <li>
                                <a href="documentation.html"><i class="icon_key_alt"></i> Documentation</a>
                            </li>
                            <li>
                                <a href="documentation.html"><i class="icon_key_alt"></i> Documentation</a>
                            </li>
                        </ul>
                    </li>
                    <!-- user login dropdown end -->
                </ul>
                <!-- notificatoin dropdown end-->
            </div>
      </header>      
      <!--header end-->

      <!--sidebar start-->
      <aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <ul class="sidebar-menu">                
                  <li class="active">
                      <a class="" href="index.html">
                          <i class="icon_house_alt"></i>
                          <span>Dashboard</span>
                      </a>
                  </li>
				  <li class="sub-menu">
                      <a href="javascript:;" class="">
                          <i class="icon_document_alt"></i>
                          <span>Forms</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
                      <ul class="sub">
                          <li><a class="" href=<?php echo base_url();?>menu/add_user>Add User</a></li>                          
                          <li><a class="" href=<?php echo base_url();?>menu/reg_student>Register Student</a></li>
                          <li><a class="" href=<?php echo base_url();?>menu/reg_teacher>Register Teacher</a></li>                          
                          <li><a class="" href=<?php echo base_url();?>menu/courses>Courses</a></li>
                          <li><a clas=""  href=<?php echo base_url();?>menu/subject>Add Subject</a></li>
                          <li><a class="" href=<?php echo base_url();?>menu/prospectus>Prospectus</a></li>                          
                          <li><a class="" href=<?php echo base_url();?>menu/pro_subject>Prospectus Subjects</a></li>
                      </ul>
                  </li>       
                  <li class="sub-menu">
                      <a href="javascript:;" class="">
                          <i class="icon_desktop"></i>
                          <span>UI Fitures</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
                      <ul class="sub">
                          <li><a class="" href="general.html">Components</a></li>
                          <li><a class="" href="buttons.html">Buttons</a></li>
                          <li><a class="" href="grids.html">Grids</a></li>
                      </ul>
                  </li>
                  <li>
                      <a class="" href="widgets.html">
                          <i class="icon_genius"></i>
                          <span>Widgets</span>
                      </a>
                  </li>
                  <li>                     
                      <a class="" href="chart-chartjs.html">
                          <i class="icon_piechart"></i>
                          <span>Charts</span>
                          
                      </a>
                                         
                  </li>
                             
                  <li class="sub-menu">
                      <a href="javascript:;" class="">
                          <i class="icon_table"></i>
                          <span>Tables</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
                      <ul class="sub">
                          <li><a class="" href="basic_table.html">Basic Table</a></li>
                      </ul>
                  </li>
                  
                  <li class="sub-menu">
                      <a href="javascript:;" class="">
                          <i class="icon_documents_alt"></i>
                          <span>Pages</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
                      <ul class="sub">                          
                          <li><a class="" href="profile.html">Profile</a></li>
                          <li><a class="" href="login.html"><span>Login Page</span></a></li>
                          <li><a class="" href="blank.html">Blank Page</a></li>
                          <li><a class="" href="404.html">404 Error</a></li>
                      </ul>
                  </li>
                  
              </ul>
              <!-- sidebar menu end-->
          </div>
      </aside>
      <!--sidebar end-->

      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">
		  <div class="row">
				<div class="col-lg-12">
					<h3 class="page-header"><i class="fa fa-file-text-o"></i> Form elements</h3>
					<ol class="breadcrumb">
						<li><i class="fa fa-home"></i><a href="index.html">Home</a></li>
						<li><i class="icon_document_alt"></i>Forms</li>
						<li><i class="fa fa-file-text-o"></i>Form elements</li>
					</ol>
				</div>
			</div>
              <div class="row">
                  <div class="col-lg-12">
                      <section class="panel">
                          <header class="panel-heading">
                             Register Student
                          </header>

                          <div class="panel-body">
                             
                                  <?php echo form_open('student_validation/information_student/'); ?>
                
                <?if($this->session->flashdata('flashSuccess')):?>
                <p class='flashMsg flashSuccess'> <?=$this->session->flashdata('flashSuccess')?> </p>
                <?endif?>
            
            <div class = "form-group">
                <?php if(isset($ins_msg)){echo $ins_msg;} ?> 
                </div>
                
            
                        <table border ="0" cellpadding="">
                            <tr>
                                <td>
                                    <?php echo form_error('course'); ?>
                                    <div class="form-group">
                                        <label for="course">Course</label>
                                        <select class="form-control"  id="course" name="course" type="text" value="<?php echo set_value('course');?>" aria-required="true" required="required" placeholder="Course"> >
                                                 <option value="">----------</option>
                                                <option value="BEED">Bachelor of Elementary Education</option>
                                                <option value="BSED">Bachelor of Secondary Education</option>
                                                <option value="BSIT">Bachelor of Science in Information Technology</option>
                                        </select>
                                    </div> 
                                </td>
                            </tr>

                             <tr>
                                <td colspan = "3">
                                    <div class="form-group">
                                     <?php echo form_error('prospectus_course'); ?>
                                        <label for="prospectus_course">Prospectus Course</label><?php echo form_error('prospectus_course'); ?>
                                        <input class="form-control" id="prospectus_course" name="prospectus_course" type="text" value="<?php echo set_value('prospectus_course');?>" size="30" aria-required="true" required="required" placeholder="Prospectus">
                                    </div> 
                                </td>
                            </tr>

                            <tr>
                                <td colspan = "2">
                                <?php echo form_error('student_id_number'); ?>
                                    <div class="form-group">
                                        <label for="student_id_number">Student ID No.</label> 
                                        <input class="form-control" id="student_id_number" name="student_id_number" type="text" value="<?php echo set_value('student_id_number'); ?>" size="30" aria-required="true" required="required" placeholder ="Student ID Number">
                                    </div>
                                </td>                               
                            </tr>

                            <tr> 
                                <td> <h3>PERSONAL INFORMATION</h3> </td>
                            </tr>
							
                            <tr>
                                <td>
                                <?php echo form_error('student_last_name'); ?>
                                    <div class="form-group">
                                        <label for="student_last_name">Last Name</label>
                                        <input class="form-control" id="student_last_name" name="student_last_name" type="text" value="<?php echo set_value('student_last_name');?>" size="30" aria-required="true" required="required" placeholder="Last Name">
                                    </div>
                                </td>

                                <td>
                                <?php echo form_error('student_first_name'); ?>
                                    <div class="form-group">
                                        <label for="student_first_name">First Name</label>
                                        <input class="form-control" id="student_first_name" name="student_first_name" type="text" value="<?php echo set_value('student_first_name');?>" size="30" aria-required="true" required="required" placeholder="First Name">
                                    </div>
                                </td>
                            
                                <td>
                                    <div class="form-group">
                                        <label for="middle_name">Middle Name</label><?php echo form_error('middle_name'); ?>
                                        <input class="form-control" id="middle_name" name="middle_name" type="text" value="<?php echo set_value('middle_name');?>" size="30" aria-required="true" required="required" placeholder="Middle Name">
                                    </div> 
                                </td>
                            </tr>
                                
                            <tr>
                                <td>
                                    <div class="form-group">
                                        <label for="birth_date">Date of Birth</label><?php echo form_error('date_of_birth'); ?>
                                        <input type="date" class="form-control" id="date_of_birth" name="date_of_birth" value="<?php echo set_value('date_of_birth');?>">
                                    </div>
                                </td> 
                            
                                <td>
                                    <div class="form-group">
                                        <label for="place_of_birth">Place of Birth</label><?php echo form_error('place_of_birth'); ?>
                                        <input class="form-control" id="place_of_birth" name="place_of_birth" type="text" value="<?php echo set_value('place_of_birth');?>" size="30" aria-required="true" required="required" placeholder="Place of Birth">
                                    </div>
                                </td>
                                
                                <td>
                                    <div class="form-group">
                                        <label for="contact_no">Contact No.</label><?php echo form_error('contact_no'); ?>
                                        <input class="form-control" id="contact_no" name="contact_no" type="text" value="<?php echo set_value('contact_no');?>" size="30" aria-required="true" required="required" placeholder="Tell./Cell">
                                    </div>
                                </td>
                            </tr>
                            
                            <tr> 
                                <td colspan="2">
                                    <div class="form-group">
                                        <label for="home_address">Home Adress</label><?php echo form_error('home_address'); ?>
                                        <input class="form-control" id="home_address" name="home_address" type="text" value="<?php echo set_value('home_address');?>" size="30" aria-required="true" required="required" placeholder="Home Address">
                                    </div>
                                </td>
                            
                                <td>
                                    <div class="form-group">
                                        <label for="home_tellno">Tell./Cell</label><?php echo form_error('home_tellno'); ?>
                                        <input class="form-control" id="home_tellno" name="home_tellno" type="text" value="<?php echo set_value('home_tellno');?>" size="30" aria-required="true" required="required" placeholder="Tell./Cell">
                                    </div>
                                </td>
                            </tr>
                            
                            <tr>
                                <td colspan="2">
                                    <div class="form-group">
                                        <label for="city_address">City Address</label><?php echo form_error('city_address'); ?>
                                        <input class="form-control" id="city_address" name="city_address" type="text" value="<?php echo set_value('city_address');?>" size="30" aria-required="true" required="required" placeholder="City Address">
                                    </div> 
                                </td>
                            
                                <td>
                                    <div class="form-group">
                                        <label for="cell_no">Tell./Cell</label><?php echo form_error('cell_no'); ?>
                                        <input class="form-control" id="cell_no" name="cell_no" type="text" value="<?php echo set_value('cell_no');?>" size="30" aria-required="true" required="required" placeholder="Tell./Cell">
                                    </div>
                                </td>
                            </tr>
                            
                            <tr>
                                <td colspan="2">
                                    <div class="form-group">
                                        <label for="boarding_address">Boarding Address</label><?php echo form_error('boarding_address'); ?>
                                        <input class="form-control" id="boarding_address" name="boarding_address" type="text" value="<?php echo set_value('boarding_address');?>" size="30" aria-required="true" required="required" placeholder="Boarding Address">
                                    </div> 
                                </td>
                            
                                <td>
                                    <div class="form-group">
                                        <label for="boarding_cel_no">Tell./Cell</label><?php echo form_error('boarding_cel_no'); ?>
                                        <input class="form-control" id="boarding_cel_no" name="boarding_cel_no" type="text" value="<?php echo set_value('boarding_cel_no');?>" size="30" aria-required="true" required="required" placeholder="Tell./Cell">
                                    </div>
                                </td>
                            </tr>
                            
                            <tr>
                                <td colspan="2">
                                    <div class="form-group">
                                        <label for="provincial_address">Provincial Address</label><?php echo form_error('provincial_address'); ?>
                                        <input class="form-control" id="provincial_address" name="provincial_address" type="text" value="<?php echo set_value('provincial_address');?>" size="30" aria-required="true" required="required" placeholder="Provincial Address">
                                    </div> 
                                </td>
                            
                                <td>
                                    <div class="form-group">
                                        <label for="provincial_tel_no">Tell./Cell</label><?php echo form_error('provincial_tel_no'); ?>
                                        <input class="form-control" id="provincial_tel_no" name="provincial_tel_no" type="text" value="<?php echo set_value('provincial_tel_no');?>" size="30" aria-required="true" required="required"  placeholder="Tell./Cell">
                                    </div>
                                </td>
                            </tr>
                            
                            <tr>
                                <td colspan="2">
                                    <div class="form-group">
                                        <label for="email_address">Email Address</label><?php echo form_error('email_address'); ?>
                                        <input class="form-control" id="email_address" name="email_address" type="email" value="<?php echo set_value('email_address');?>" size="30" aria-required="true" required="required" placeholder="Email Add">
                                    </div> 
                                </td>
                            </tr>
            
                            <tr>
                                <td colspan="1">
                                    <div class="form-group">
                                        <label for="nationality">Nationality</label><?php echo form_error('nationality'); ?>
                                        <input class="form-control" id="nationality" name="nationality" type="text" value="<?php echo set_value('nationality');?>" size="30" aria-required="true" required="required" placeholder="Nationality">
                                    </div>
                                </td>
                            
                                <td>
                                    <div class="form-group">
                                        <label for="religion">Religion</label><?php echo form_error('religion'); ?>
                                        <input class="form-control" id="religion" name="religion" type="text" value="<?php echo set_value('religion');?>" size="30" aria-required="true" required="required" placeholder="Religion">
                                    </div>
                                </td>
                             </tr>
                                
                              <tr>
                                <td>
                                    <div class="form-group">
                                    	<?php echo form_error('civil_status'); ?>
                                        <label for="civil_status">Civil Status</label>
                                         <select name="civil_status">
                                            <option value="Single">Single</option>
                                            <option value="Married">Married</option>
                                            <option value="Widowed">Widowed</option>
                                            <option value="Divorced">Divorced</option>
                                        </select>
                                    </div>
                                </td>
                        
                            
                               
                                <td colspan="1">
                                <?php echo form_error('gender'); ?>
                                    <div class="form-group">
                                        <label for="gender">Gender:</label>
                                        <input type="radio" value="Male" name="gender">Male
                                        <input type="radio" value="Female" name="gender">Female
                                    </div> 
                                </td>
                            </tr>
                            
                            <tr>
                                <td colspan="3">
                                    <div class="form-group">
                                        <label for="name_of_spouse_if_married">Name of Spouse(if Married)</label><?php echo form_error('name_of_spouse_if_married'); ?>
                                        <input class="form-control" id="name_of_spouse_if_married" name="name_of_spouse_if_married" type="text" value="<?php echo set_value('name_of_spouse_if_married');?>" size="30" aria-required="true" required="required" placeholder="Name of Spouse (if Married)">
                                    </div>
                                </td>
                            </tr>
                            

                            <tr>
                                <td colspan="3">
                                    <div class="form-group">
                                        <label for="name_of_employer_if_working">Name of Employer, if working </label><?php echo form_error('name_of_employer_if_working'); ?>
                                        <input class="form-control" id="name_of_employer_if_working" name="name_of_employer_if_working" type="text" value="<?php echo set_value('name_of_employer_if_working');?>" size="30" aria-required="true" required="required" placeholder="Name of Employer, if working">
                                    </div>
                                </td>
                            </tr>
                            
                            <tr>
                                <td colspan="2">
                                    <div class="form-group">
                                        <label for="employer_address">Address</label><?php echo form_error('employer_address'); ?>
                                        <input class="form-control" id="employer_address" name="employer_address" type="text" value="<?php echo set_value('employer_address');?>" size="30" aria-required="true" required="required" placeholder="Address">
                                    </div>
                            
                                <td>
                                    <div class="form-group">
                                        <label for="employer_cel_no">Tell./Cell</label><?php echo form_error('employer_cel_no'); ?>
                                        <input class="form-control" id="employer_cel_no" name="employer_cel_no" type="text" value="<?php echo set_value('employer_cel_no');?>" size="30" aria-required="true" required="required" placeholder="Tell./Cell">
                                    </div>
                                </td>
                            </tr>
                            
                            <tr>
                                <td colspan="3">
                                    <h3>FAMILY BACKGROUND</h3>
                                </td>
                            </tr>
                            
                            <tr>
                                <td colspan="2">
                                    <div class="form-group">
                                        <label for="fathers_name">Father`s Name</label><?php echo form_error('fathers_name'); ?>
                                        <input class="form-control" id="fathers_name" name="fathers_name" type="text" value="<?php echo set_value('fathers_name');?>" size="30" aria-required="true" required="required" placeholder="Father's Name">
                                    </div>
                                </td>
                            
                                <td>
                                    <div class="form-group">
                                        <label for="fathers_occupation">Occupation</label><?php echo form_error('fathers_occupation'); ?>
                                        <input class="form-control" id="fathers_occupation" name="fathers_occupation" type="text" value="<?php echo set_value('fathers_occupation');?>" size="30" aria-required="true" required="required" placeholder="Occupation">
                                    </div>
                                </td>
                            </tr>
                            
                            
                            <tr>
                                <td colspan="3">
                                    <div class="form-group">
                                        <label for="father_educ_attainment">Educational Attainment</label><?php echo form_error('father_educ_attainment'); ?>
                                        <input class="form-control" id="father_educ_attainment" name="father_educ_attainment" type="text" value="<?php echo set_value('father_educ_attainment');?>" size="30" aria-required="true" required="required" placeholder="Educational Attainment">
                                    </div>
                                <td>
                            </tr>
                            
                            <tr>
                                <td colspan="2">
                                    <div class="form-group">
                                        <label for="mothers_name">Mother`s Name</label><?php echo form_error('mothers_name'); ?>
                                        <input class="form-control" id="mothers_name" name="mothers_name" type="text" value="<?php echo set_value('mothers_name');?>" size="30" aria-required="true" required="required" placeholder="Mother's Name">
                                    </div>
                                </td>
                            
                                <td>
                                    <div class="form-group">
                                        <label for="mothers_occupation">Occupation</label><?php echo form_error('mothers_occupation'); ?>
                                        <input class="form-control" id="mothers_occupation" name="mothers_occupation" type="text" value="<?php echo set_value('mothers_occupation');?>" size="30" aria-required="true" required="required" placeholder="Occupation">
                                    </div>
                                </td>
                            </tr>
                            
                            <tr>
                                <td colspan="3">
                                    <div class="form-group">
                                        <label for="mother_educ_attainment">Educational Attainment</label><?php echo form_error('mother_educ_attainment'); ?>
                                        <input class="form-control" id="mother_educ_attainment" name="mother_educ_attainment" type="text" value="<?php echo set_value('mother_educ_attainment');?>" size="30" aria-required="true" required="required" placeholder="Educational Attainment">
                                    </div>
                                <td>
                            </tr>
                            
                            <tr>
                                <td colspan="2">
                                    <div class="form-group">
                                        <label for="guardians_name">Guardian`s Name</label><?php echo form_error('guardians_name'); ?>
                                        <input class="form-control" id="guardians_name" name="guardians_name" type="text" value="<?php echo set_value('guardians_name');?>" size="30" aria-required="true" required="required" placeholder="Guardian's Name">
                                    </div>
                                </td>
                                
                                <td>
                                    <div class="form-group">
                                        <label for="guardian_occupation">Occupation</label><?php echo form_error('guardian_occupation'); ?>
                                        <input class="form-control" id="guardian_occupation" name="guardian_occupation" type="text" value="<?php echo set_value('guardian_occupation');?>" size="30" aria-required="true" required="required" placeholder="Occupation">
                                    </div>
                                </td>
                            </tr>
                            
                            <tr>
                                <td colspan="2">
                                    <div class="form-group">
                                        <label for="guardians_address">Address</label><?php echo form_error('guardians_address'); ?>
                                        <input class="form-control" id="guardians_address" name="guardians_address" type="text" value="<?php echo set_value('guardians_address');?>" size="30" aria-required="true" required="required" placeholder="Address">
                                    </div>
                                </td>
                            
                                <td>
                                    <div class="form-group">
                                        <label for="guardians_cel_no">Tell./Cell</label><?php echo form_error('guardians_cel_no'); ?>
                                        <input class="form-control" id="guardians_cel_no" name="guardians_cel_no" type="text" value="<?php echo set_value('guardians_cel_no');?>" size="30" aria-required="true" required="required" placeholder="Tell./Cell">
                                    </div>
                                </td>
                            </tr>
                            
                            <tr>
                                <td colspan="3">
                                    <div class="form-group">
                                        <label for="guardian_educ_attainment">Educational Attainment</label><?php echo form_error('guardian_educ_attainment'); ?>
                                        <input class="form-control" id="guardian_educ_attainment" name="guardian_educ_attainment" type="text" value="<?php echo set_value('guardian_educ_attainment');?>" size="30" aria-required="true" required="required" placeholder="Educational Attainment">
                                    </div>
                                </td>
                            </tr>
                            
                            <tr>
                                <td colspan="2">
                                    <div class="form-group">
                                        <label for="guardian_relationship">Relationship to Guardian</label><?php echo form_error('guardian_relationship'); ?>
                                        <input class="form-control" id="guardian_relationship" name="guardian_relationship" type="text" value="<?php echo set_value('guardian_relationship');?>" size="30" aria-required="true" required="required" placeholder="Relationship to Guardian">
                                    </div>
                                </td>
                            </tr>
                            
                            <tr>
                                <td colspan="3">
                                    <div class="form-group">
                                        <label for="grades_to_be_sent_to">Grades to be Sent To</label><?php echo form_error('grades_to_be_sent_to'); ?>
                                        <input class="form-control" id="grades_to_be_sent_to" name="grades_to_be_sent_to" type="text" value="<?php echo set_value('grades_to_be_sent_to');?>" size="30" aria-required="true" required="required" placeholder="Grades to be Sent To">
                                    </div>
                                </td>
                            </tr>
                            
                            <tr>
                                <td colspan="2">
                                    <div class="form-group">
                                        <label for="grades_to_sent_address">Address</label><?php echo form_error('grades_to_sent_address'); ?>
                                        <input class="form-control" id="grades_to_sent_address" name="grades_to_sent_address" type="text" value="<?php echo set_value('grades_to_sent_address');?>" size="30" aria-required="true" required="required" placeholder="Address">
                                    </div>
                                </td>
                            
                                <td>
                                    <div class="form-group">
                                        <label for="grades_cel_no">Tell./Cell</label><?php echo form_error('grades_cel_no'); ?>
                                        <input class="form-control" id="grades_cel_no" name="grades_cel_no" type="text" value="<?php echo set_value('grades_cel_no');?>" size="30" aria-required="true" required="required" placeholder="Tell./Cell">
                                    </div>
                                </td>
                            </tr>

                            <tr>
                                <td colspan="3">
                                    <h3>EDUCATIONAL BACKGROUND </h3>
                                </td>
                            </tr>
                            
                            <tr>
                                <td colspan="2">
                                    <div class="form-group">
                                        <label for="elementary">Elementary</label><?php echo form_error('elementary'); ?>
                                        <input class="form-control" id="elementary" name="elementary" type="text" value="<?php echo set_value('elementary')?>" size="30" aria-required="true" required="required" placeholder="Elementary">
                                    </div>
                                </td>
                            
                                <td>
                                    <div class="form-group">
                                        <label for="elementary_sy">School Year</label><?php echo form_error('elementary_sy'); ?>
                                        <input class="form-control" id="elementary_sy" name="elementary_sy" type="text" value="<?php echo set_value('elementary_sy');?>" size="30" aria-required="true" required="required" placeholder="School Year">
                                    </div>
                                </td>
                            </tr>
                            
                            <tr>
                                <td colspan="3">
                                    <div class="form-group">
                                        <label for="elementary_address">Address</label><?php echo form_error('elementary_address'); ?>
                                        <input class="form-control" id="elementary_address" name="elementary_address" type="text" value="<?php echo set_value('elementary_address');?>" size="30" aria-required="true" required="required" placeholder="School Address">
                                    </div>
                                </td>
                            </tr>
                            
                            <tr>
                                <td colspan="2">
                                    <div class="form-group">
                                        <label for="high_school">High School</label><?php echo form_error('high_school'); ?>
                                        <input class="form-control" id="high_school" name="high_school" type="text" value="<?php echo set_value('high_school');?>" size="30" aria-required="true" required="required" placeholder="High School">
                                    </div>
                                </td>
                            
                                <td>
                                    <div class="form-group">
                                        <label for="high_school_sy">School Year</label><?php echo form_error('high_school_sy'); ?>
                                        <input class="form-control" id="high_school_sy" name="high_school_sy" type="text" value="<?php echo set_value('high_school_sy');?>" size="30" aria-required="true" required="required" placeholder="School Year">
                                    </div>
                                </td>
                            <tr>
                            
                            <tr>
                                <td colspan="3">
                                    <div class="form-group">
                                        <label for="high_school_address">Address</label><?php echo form_error('high_school_address'); ?>
                                        <input class="form-control" id="high_school_address" name="high_school_address" type="text" value="<?php echo set_value('high_school_address');?>" size="30" aria-required="true" required="required" placeholder="School Address">
                                    </div>
                                </td>
                            </tr>
                            
							<tr>
								<td>
									<h5>IF TRANSFEREE</h5>
								<td>
							<tr>
							
                            <tr>
                                <td colspan="2">
                                    <div class="form-group">
                                        <label for="college">School Last Attended: College</label><?php echo form_error('college'); ?>
                                        <input class="form-control" id="college" name="college" type="text" value="<?php echo set_value('college');?>" size="30" aria-required="true" required="required" placeholder="College">
                                    </div>
                                </td>
                            
                                <td>
                                    <div class="form-group">
                                        <label for="college_sy">School Year</label><?php echo form_error('college_sy'); ?>
                                        <input class="form-control" id="college_sy" name="college_sy" type="text" value="<?php echo set_value('college_sy');?>" size="30" aria-required="true" required="required" placeholder="School Year">
                                    </div>
                                </td>
                            <tr>
                            
                            <tr>
                                <td colspan="3">
                                    <div class="form-group">
                                        <label for="college_address">Address</label><?php echo form_error('college_address'); ?>
                                        <input class="form-control" id="college_address" name="college_address" type="text" value="<?php echo set_value('college_address');?>" size="30" aria-required="true" required="required" placeholder="College Address">
                                    </div>
                                </td>
                            </tr>
                            
                                                
                            <tr>
                                <td>
                                    <button type="submit" name = "submit" class="btn btn-primary" id="submit" onClick='return checkname()'>Submit</button>
                                </td>
                                
                                <td colspan="2">
                                    <button type="reset" class="btn btn-primary" id="clear" value="reset">Clear</button>
                                </td>
                            </tr>
                        </table>
                    <?php echo form_close();?>
                </div>
      <!--main content end-->
  </section>
  <!-- container section end -->       
    <!-- javascripts -->
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <!-- nice scroll -->
    <script src="js/jquery.scrollTo.min.js"></script>
    <script src="js/jquery.nicescroll.js" type="text/javascript"></script>

    <!-- jquery ui -->
    <script src="js/jquery-ui-1.9.2.custom.min.js"></script>

    <!--custom checkbox & radio-->
    <script type="text/javascript" src="js/ga.js"></script>
    <!--custom switch-->
    <script src="js/bootstrap-switch.js"></script>
    <!--custom tagsinput-->
    <script src="js/jquery.tagsinput.js"></script>
    
    <!-- colorpicker -->
   
    <!-- bootstrap-wysiwyg -->
    <script src="js/jquery.hotkeys.js"></script>
    <script src="js/bootstrap-wysiwyg.js"></script>
    <script src="js/bootstrap-wysiwyg-custom.js"></script>
    <!-- ck editor -->
    <script type="text/javascript" src="assets/ckeditor/ckeditor.js"></script>
    <!-- custom form component script for this page-->
    <script src="js/form-component.js"></script>
    <!-- custome script for all page -->
    <script src="js/scripts.js"></script>
  

  </body>
</html>
