<body>
  <div class="col-md-6 col-md-offset-3">
<?=form_open('File_students/search');?>
<?php $search = array('name'=>'search','id'=>'search','value'=>"",);?>
<?=form_input($search);?><input type=submit value='Search' /></p>
<?=form_close();?>

<table>
<tr><th>Student ID|</th><th>Last Name|</th><th>First Name|</th><th>Middle Name</th></tr>
</table>

</div>
</div>
</body>