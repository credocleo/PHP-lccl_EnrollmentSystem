
<body>
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">LCC - L</a>
    </div>
	
    <div>
      <ul class="nav navbar-nav">
        <li class="active"><a href=<?php echo base_url();?>menu/home>Home</a></li>
		    <li><a href=<?php echo base_url();?>menu/add_user>Add User</a></li>
		    <li><a href=<?php echo base_url();?>menu/reg_student>Register New Student</a></li>
			<li><a href=<?php echo base_url();?>menu/reg_teacher>Register Teacher</a></li>
			<li><a href=<?php echo base_url();?>menu/courses>Courses</a></li>
			<li><a href=<?php echo base_url();?>menu/subject>Add Subject</a></li>
			<li><a href=<?php echo base_url();?>menu/prospectus>Prospectus</a></li>
			<li><a href=<?php echo base_url();?>menu/pro_subject>Prospectus Subjects</a></li>
			<li><a href=<?php echo base_url();?>menu/list_of_student>Student List</a></li>
      		<li><a href=<?php echo base_url();?>menu/search>Search</a></li>
      </ul>
	  
        
	  <div>
			<ul id="settings">
			 <li><a href=<?php echo base_url();?>logout/index>Log Out</a></li>
			</ul>
    </div>
  </div>
</nav>

</body>
</html>
