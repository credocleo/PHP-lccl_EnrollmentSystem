<html>
	<head>
 		<meta charset="utf-8">
 		<meta name="viewport" content="width=device-width, initial-scale=1.0">
 		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="css/query-ul.min.css" rel="stylesheet">
		
		
    </head>

<body>	

	<form>
			<div class="col-md-6 col-md-offset-3">
				<table border ="0" cellpadding="">
			
						<tr>
							<td colspan="3">
								<H1>GRADE SHEET</h1></br>
							</td>
						</tr>
						
						<tr>
							<td>
								<div class="form-group">
									<label for="studentNo">Date</label>
									<input type="date" class="form-control" id="date" name="date" placeholder="StudentNo">
								</div>
							</td> 
						</tr>
							
						<tr>
							<td>
								<div class="form-group">
									<label for="FirstName">Semester</label>
									<input class="form-control" id="Semester" name="Semester" type="text" value="" size="30" aria-required="true" required="required" placeholder="Semester">
								</div> 
							</td>
							
							<td>
								<div class="form-group">
									<label for="MiddleName">A.Y.</label>
									<input class="form-control" id="academic_year" name="academic_year" type="text" value="" size="30" aria-required="true" required="required" placeholder="Academic Year">
								</div>
							</td>
						</tr>
							
						<tr>
							<td>
								<div class="form-group">
									<label for="FirstName">Section Code</label>
									<input class="form-control" id="section_code" name="section_code" type="text" value="" size="30" aria-required="true" required="required" placeholder="Section Code">
								</div>
							</td>
							
							<td>
								<div class="form-group">
									<label for="LastName">Days</label>
									<input class="form-control" id="days" name="days" type="text" value="" size="30" aria-required="true" required="required" placeholder="Days">
								</div>
							</td> 
							
							<td>
								<div class="form-group">
									<label for="MiddleName">Time</label>
									<input class="form-control" id="Time" name="Time" type="text" value="" size="30" aria-required="true" required="required" placeholder="Time">
								</div>		
							</td>
						</tr>
							
						<tr>
							<td>
								<div class="form-group">
									<label for="MiddleName">Subject</label>
									<input class="form-control" id="subject" name="subject" type="text" value="" size="30" aria-required="true" required="required" placeholder="Subject">
								</div>
							</td>
								
							<td>
								<div class="form-group">
									<label for="FirstName">Units</label>
									<input class="form-control" id="units" name="units" type="text" value="" size="30" aria-required="true" required="required" placeholder="Units">
								</div>
							</td>
							
							<td>
								<div class="form-group">
									<label for="MiddleName">Room</label>
									<input class="form-control" id="room" name="room" type="text" value="" size="30" aria-required="true" required="required" placeholder="Room">
								</div>
							</td>
						</tr>
								
						<tr>
							<td colspan="3">
								<div class="form-group">
									<label for="MiddleName">Description</label>
									<input class="form-control" id="description" name="description" type="text" value="" size="30" aria-required="true" required="required" placeholder="Description">
								</div> 
							</td>
						</tr>
							
						<tr>
							<td colspan="3">
								<div class="form-group">
									<label for="MiddleName">Instructor</label>
									<input class="form-control" id="instructor" name="instruction" type="text" value="" size="30" aria-required="true" required="required" placeholder="Instructor">
								</div>
							</td>
						</tr>
					</table>
</br></br>

		<table class="table table-bordered">
		
     <tr>
		<th>Seq. No.</th>
		<td>Student Number</td>
		<td>Last Name</td>
		<td>First Name</td>
		<td>M.I</td>
		<td>Prelim</td>
		<td>Mid - Term</td>
		<td>Final</td>
		<td>Final Rating</td>
	</tr>
  
	<tr>
		<th></th>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	
	<tr>
		<th></th>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	
	<tr>
		<th></th>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	
	<tr>
		<th></th>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	
	<tr>
		<th></th>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	
	<tr>
		<th></th>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	
	<tr>
		<th></th>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	
	<tr>
		<th></th>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	
	<tr>
		<th></th>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	
	<tr>
		<th></th>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	
	<tr>
		<th></th>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	
	
  
	
</table>
</div>

<script src="js/jquery.js.js"></script>
<script src="js/bootstrap.min.js"></script>



</form>
 </body>
 </html>
