
<body>
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">LCC - L</a>
    </div>
	
    <div>
      <ul class="nav navbar-nav">
        <li class="active"><a href=<?php echo base_url();?>menu_student/home>STUDENT RECORDS</a></li>
		    <li><a href=<?php echo base_url();?>menu_student/students_grades>Grade</a></li>
		    
			<li><a href=<?php echo base_url();?>menu_student/class_subject_enrolled>Subjects Enrolled</a></li>
			<li><a href=<?php echo base_url();?>menu_student/student_class_schedule>Class Schedule</a></li>
      </ul>
	  
	  <div>
			<ul id="settings">
			<li><a>Log Out</a></li>
			</ul>

    </div>
  </div>
</nav>

    

</body>
</html>
