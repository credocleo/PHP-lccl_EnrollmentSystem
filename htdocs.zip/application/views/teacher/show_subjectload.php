<form>
			<div class="col-md-6 col-md-offset-3">	
				<fieldset class="scheduler-border">
				    <legend class ="scheduler-border">User Information:</legend>
				    Student ID NO.: <?php echo $info->student_id_number;?><br>
				    Last Name: <?php echo $info->student_last_name;?><br>
				    First Name: <?php echo $info->student_first_name;?><br>
					Middle Name: <?php echo $info->middle_name;?><br>
					Course: <?php echo $info->course;?><br>
					
				</fieldset>			
</br>
		<table class="table table-bordered">
			
<tr><td colspan="7"><br><center><b>SUBJECT 	LOAD<br></center></td></tr>

<tr>
<td><b><center><br>Course Number</center></b></td>
<td><center><br><b>Descriptive Title<b/></center></td>
<td><center><b><br>Units</b></center></td>
<td><center><b><br>Day</b></center></td>
<td><center><b><br>Time</b></center></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>

</table>
</div>
</center>
</div>