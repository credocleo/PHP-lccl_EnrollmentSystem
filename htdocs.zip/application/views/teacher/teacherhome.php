 
<!DOCTYPE html>
<html lang="en">

	<head>
 		<meta charset="utf-8">
 		<meta name="viewport" content="width=device-width, initial-scale=1.0">
 		<link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
		<link href="<?php echo base_url();?>css/jquery-ui.min.css" rel="stylesheet">
    </head>

<body>
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">LCC - L</a>
    </div>
	
    <div>
      <ul class="nav navbar-nav">
          <li ><a href=<?php echo base_url();?>menu_teacher/pick_subjectschedule>Pick Subject Schedule</a></li>
		    <li><a href=<?php echo base_url();?>menu_teacher/show_subjectload>Show Subject Load</a></li>
			<li><a href=<?php echo base_url();?>menu_teacher/home>Show Student</a></li>
			<li><a href=<?php echo base_url();?>menu_teacher/input_grades>Input Grades</a></li>
      </ul>
	  
	 <div>
			<ul class="nav navbar-nav navbar-right">
      			<li><a href="/logout">Log out</a></li>
      </ul>

    </div>
  </div>
</nav>


 
    

</body>
</html>
