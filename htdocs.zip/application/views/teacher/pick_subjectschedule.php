<html>
	<head>
 		<meta charset="utf-8">
 		<meta name="viewport" content="width=device-width, initial-scale=1.0">
 		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="css/query-ul.min.css" rel="stylesheet">
		
		
    </head>

<body>
<form>
			<div class="col-md-6 col-md-offset-3">				
</br>
		<table class="table table-bordered">
			
<tr><td colspan="7"><br><center><b>SUBJECT SCHEDULE<br></center></td></tr>

<tr>
<td><b><center><br>Course Number</center></b></td>
<td><center><br><b>Descriptive Title<b/></center></td>
<td><center><b><br>Day</b></center></td>
<td><center><b><br>Time</b></center></td>
<td><center><b><br>Room</b></center></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>

</table>
</div>
</center>

</table>



</div>

<script src="js/jquery.js.js"></script>
<script src="js/bootstrap.min.js"></script>


 
</body>
</html>