<body>
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">LCC - L</a>
    </div>
	
    <div>
      <ul class="nav navbar-nav">
        <li class="active"><a href=menu/subject>Add Subject</a></li>
			<li><a href=menu/input_student_grade>Input Student Grade</a></li>
      </ul>
	  
	  <div>
			<ul id="settings">
			<li><a href=logout/index>Log Out</a></li>
			</ul>

    </div>
  </div>
</nav>