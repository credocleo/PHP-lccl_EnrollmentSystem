
<body>
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">LCC - L</a>
    </div>
	
    <div>
      <ul class="nav navbar-nav">
        <li class="active"><a href=<?php echo base_url();?>menu_student/home>STUDENT RECORDS</a></li>
		    <li><a href=<?php echo base_url();?>student/students_grades>Grade</a></li>
		  
      <li><a href=<?php echo base_url();?>student/student_prospectus>Prospectus</a></li>
      <li><a href=<?php echo base_url();?>student/student_subject_offered>Subject Offered</a></li>
			<li><a href=<?php echo base_url();?>student/class_subject_enrolled>Subjects Enrolled</a></li>

      </ul>
     </div> 

	  
	  <div>
			<ul class="nav navbar-nav navbar-right">
      			<li><a href="/logout">Log out</a></li>
      </ul>

    </div>
 
</nav>

    

</body>
</html>
