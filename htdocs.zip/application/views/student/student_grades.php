

<form>
			<div class="col-md-6 col-md-offset-3">
				<?php $info = $info->row();?>
				<fieldset class="scheduler-border">
				    <legend class ="scheduler-border">User Information:</legend>
				    Student ID NO.: <?php echo $info->student_id_number;?><br>
				    Last Name: <?php echo $info->student_last_name;?><br>
				    First Name: <?php echo $info->student_first_name;?><br>
					Middle Name: <?php echo $info->middle_name;?><br>
					Course: <?php echo $info->course;?><br>
					
				</fieldset>
					
</br></br>
		<table class="table table-bordered">
		
     <tr>
		<th>Subject Code</th>
		<td>Course No.</td>
		<td>Course Description</td>
		<td>Units</td>
		<td>Mid Term Grade</td>
		<td>Final Grade</td>
		<td>Instructor's Name</td>
	</tr>
  
	<tr>
		<th></th>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	
	<tr>
		<th></th>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	
	<tr>
		<th></th>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	
	<tr>
		<th></th>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	
	<tr>
		<th></th>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	
	<tr>
		<th></th>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	
	<tr>
		<th></th>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	
	<tr>
		<th></th>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	
	<tr>
		<th></th>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	
	<tr>
		<th></th>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	
	<tr>
		<th></th>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	
	
  
	
</table>
</div>

