<html>
	<head>
 		<meta charset="utf-8">
 		<meta name="viewport" content="width=device-width, initial-scale=1.0">
 		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="css/query-ul.min.css" rel="stylesheet">
		
		
    </head>

<body>	

<form>
			<div class="col-md-6 col-md-offset-3">
			<table border ="0" cellpadding="">
			
						<tr>
							<td colspan="3">
								<H1>SUBJECTS OFFERED</h1></br>
							</td>
						</tr>
						
						<tr>
							<td>
								<div class="form-group">
									<label for="studentNo">Date</label>
									<input type="date" class="form-control" id="date" name="date" placeholder="StudentNo">
								</div>
							</td>
						</tr>
							
						<tr>
							<td>
								<div class="form-group">
									<label for="FirstName">Semester</label>
									<input class="form-control" id="Semester" name="Semester" type="text" value="" size="30" aria-required="true" required="required" placeholder="Semester">
								</div>
							</td>
							
							<td>
								<div class="form-group">
									<label for="MiddleName">A.Y.</label>
									<input class="form-control" id="academic_year" name="academic_year" type="text" value="" size="30" aria-required="true" required="required" placeholder="Academic Year">
								</div>
							</td>
						</tr>
							
						<tr>
							<td colspan="3">
								<div class="form-group">
									<label for="MiddleName">Course</label>
									<input class="form-control" id="course" name="course" type="text" value="" size="30" aria-required="true" required="required" placeholder="Course">
								</div>
							</td>
						</tr>
						
						<tr>
							<td>
								<div class="form-group">
									<label for="LastName">Major</label>
									<input class="form-control" id="major" name="major" type="text" value="" size="30" aria-required="true" required="required" placeholder="Major">
								</div>
							</td> 
							
							<td>
								<div class="form-group">
									<label for="MiddleName">Year Level</label>
									<input class="form-control" id="year_level" name="year_level" type="text" value="" size="30" aria-required="true" required="required" placeholder="Year Level">
								</div> 
							</td>
						</tr>
					</table>
					
					
</br></br>
		<table class="table table-bordered">
		
     <tr>
		<th>Subject Code</th>
		<td>Days</td>
		<td>Time</td>
		<td>Course No.</td>
		<td>Descriptive Title</td>
		<td>Units</td>
		<td>Room</td>
	</tr>
  
	<tr>
		<th></th>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	
	<tr>
		<th></th>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	
	<tr>
		<th></th>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	
	<tr>
		<th></th>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	
	<tr>
		<th></th>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	
	<tr>
		<th></th>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	
	<tr>
		<th></th>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	
	<tr>
		<th></th>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	
	<tr>
		<th></th>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	
	<tr>
		<th></th>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	
	<tr>
		<th></th>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
	</tr>
	
	
  
	
</table>
</div>

<script src="js/jquery.js.js"></script>
<script src="js/bootstrap.min.js"></script>



</form>
 </body>
 </html>
