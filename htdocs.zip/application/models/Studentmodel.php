<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Studentmodel extends CI_Model{

	function __construct()
	{
		parent::__construct();
	}
	function register_new_user()
	{
		$data = array
		(
		'account_type' => $this->input->post('account_type'),
		'username' => $this->input->post('username'),
		'password' => $this->input->post('password'),
		'confirm_password' => $this-> input->post('confirm_password')
		);
		$this->db->insert('user', $data);
	}
	function student_add()
	{
		$data = array
		(
		'student_id_number' => $this->input->post('student_id_number'),
		'student_last_name' => $this->input->post('student_last_name'),
		'student_first_name' => $this->input->post('student_first_name'),
		'middle_name' => $this->input->post('middle_name'),
		'date_of_birth' => $this->input->post('date_of_birth'),
		'place_of_birth' => $this->input->post('place_of_birth'),
		'contact_no' => $this->input->post('contact_no'),
		'home_address' => $this->input->post('home_address'),
		'home_tellno' => $this->input->post('home_tellno'),
		'city_address' => $this->input->post('city_address'),
		'cell_no' => $this->input->post('cell_no'),
		'boarding_address' => $this->input->post('boarding_address'),
		'boarding_cel_no' => $this->input->post('boarding_cel_no'),
		'provincial_address' => $this->input->post('provincial_address'),
		'provincial_tel_no' => $this->input->post('provincial_tel_no'),
		'email_address' => $this->input->post('email_address'),
		'nationality' => $this->input->post('nationality'),
		'religion' => $this->input->post('religion'),
		'civil_status' => $this->input->post('civil_status'),
		'gender' => $this->input->post('gender'),
		'name_of_spouse_if_married' => $this->input->post('name_of_spouse_if_married'),
		'name_of_employer_if_working' => $this->input->post('name_of_employer_if_working'),
		'employer_address' => $this->input->post('employer_address'),
		'employer_cel_no' => $this->input->post('employer_cel_no'),
		'fathers_name' => $this->input->post('fathers_name'),
		'fathers_occupation' => $this->input->post('fathers_occupation'),
		'father_educ_attainment' => $this->input->post('father_educ_attainment'),
		'mothers_name' => $this->input->post('mothers_name'),
		'mothers_occupation' => $this->input->post('mothers_occupation'),
		'mother_educ_attainment' => $this->input->post('mother_educ_attainment'),
		'guardians_name' => $this->input->post('guardians_name'),
		'guardian_occupation' => $this->input->post('guardian_occupation'),
		'guardians_address' => $this->input->post('guardians_address'),
		'guardians_cel_no' => $this->input->post('guardians_cel_no'),
		'guardian_educ_attainment' => $this->input->post('guardian_educ_attainment'),
		'guardian_relationship' => $this->input->post('guardian_relationship'),
		'grades_to_be_sent_to' => $this->input->post('grades_to_be_sent_to'),
		'grades_to_sent_address' => $this->input->post('grades_to_sent_address'),
		'grades_cel_no' => $this->input->post('grades_cel_no'),
		'elementary' => $this->input->post('elementary'),
		'elementary_sy' => $this->input->post('elementary_sy'),
		'elementary_address' => $this->input->post('elementary_address'),
		'high_school' => $this->input->post('high_school'),
		'high_school_sy' => $this->input->post('high_school_sy'),
		'high_school_address' => $this->input->post('high_school_address'),
		'college' => $this->input->post('college'),
		'college_sy' => $this->input->post('college_sy'),
		'college_address' => $this->input->post('college_address')
		);
		$this->db->insert('students', $data);
	}
	function teacher_info()
	{
		$data = array
		(
		'teacher_id_num' => $this->input->post('teacher_id_num'),
		't_last_name' => $this->input->post('t_last_name'),
		't_first_name' => $this->input->post('t_first_name'),
		't_middle_name' => $this->input->post('t_middle_name'),
		't_date_of_birth' => $this->input->post('t_date_of_birth'),
		't_place_of_birth' => $this->input->post('t_place_of_birth'),
		't_home_address' => $this->input->post('t_home_address'),
		't_home_tellno' => $this->input->post('t_home_tellno'),
		't_city_address' => $this->input->post('t_city_address'),
		't_cell_no' => $this->input->post('t_cell_no'),
		't_boarding_address' => $this->input->post('t_boarding_address'),
		't_boarding_cel_no' => $this->input->post('t_boarding_cel_no'),
		't_provincial_address' => $this->input->post('t_provincial_address'),
		't_provincial_tel_no' => $this->input->post('t_provincial_tel_no'),
		't_nationality' => $this->input->post('t_nationality'),
		't_religion' => $this->input->post('t_religion'),
		't_civil_status' => $this->input->post('t_civil_status'),
		't_gender' => $this->input->post('t_gender'),
		't_email_address' => $this->input->post('t_email_address')
		);
		$this->db->insert('teachers', $data);
	}
	function subjects_new()
	{
		$data = array
		(
		'subject_id' => $this->input->post('subject_id'),
		'subject_description' => $this->input->post('subject_description'),
		'subject_units' => $this->input->post('subject_units'),
		'subject_lec_hours' => $this->input->post('subject_lec_hours'),
		'subject_lab_hours' => $this->input->post('subject_lab_hours'),
		'subject_pre_req' => $this->input->post('subject_pre_req'),
		
		);
		$this->db->insert('subjects', $data);
	}
	function course_offer()
	{
		$data = array
		(
		'co_course_id' => $this->input->post('co_course_id'),
		'co_courses' => $this->input->post('co_courses'),
		'co_course_description' => $this->input->post('co_course_description')
		);
		$this->db->insert('courses', $data);
	}
	function get_info($user_name)
	{
		return $this->db->where('user_name', $user_name)->get('students');
	}

}