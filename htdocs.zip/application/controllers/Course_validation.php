<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Course_validation extends CI_Controller{
	
		function __construct()
		{
			parent:: __construct();
			$this->load->view('cache');
			$this->load->helper(array('form','url','html'));
			$this->load->library('form_validation');
			$this->form_validation->set_message('alpha','Invalid Name');
			$this->form_validation->set_message('required','Require');
			
			$this->load->model('Transactions_admin');
		}
	
	function add_course($page = 'courses_offered')
	{
		if ( ! file_exists('application/views/admin/'.$page.'.php'))
		{
			show_404();
		}
		$this->form_validation->set_rules('co_course_id','Course ID','required|is_unique[courses.co_course_id]',
			array(
				'required'		=> 'You have not provided %s.',
				'is_unique'		=> 'This %s already exists.'
				)
			);
		$this->form_validation->set_rules('co_courses','Course','required|is_unique[courses.co_courses]',
			array(
				'required'		=> 'You have not provided %s.',
				'is_unique'		=> 'This %s already exists.'
				)
			);
		$this->form_validation->set_rules('co_course_description','Description','required|is_unique[courses.co_course_description]',
			array(
				'required'		=> 'You have not provided %s.',
				'is_unique'		=> 'This %s already exists.'
				)
			);
		
		if ($this->form_validation->run() == FALSE)
		{	
			$this->load->view('header');
			$this->load->view('admin/courses_offered');
		}
		
		else
		{
			$data['query'] = $this->Transactions_admin->subjects_new();
			
			$this->session->set_flashdata('flashSuccess', 'Successfully Saved!');
			redirect('Subjects_validation/new_subject');
		
		}
	}
}