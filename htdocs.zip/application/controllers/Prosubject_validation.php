<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Prosubject_validation extends CI_Controller{
	
		function __construct()
		{
			parent:: __construct();
			$this->load->view('cache');
			$this->load->helper(array('form','url','html'));
			$this->load->library('form_validation');
			$this->form_validation->set_message('alpha','Invalid Name');
			$this->form_validation->set_message('required','Require');
			
			$this->load->model('Transactions_admin');
		}
	
	function sub($page = 'pros_subject')
	{
		if ( ! file_exists('application/views/admin/'.$page.'.php'))
		{
			show_404();
		}
		$this->form_validation->set_rules('ps_prospectus_id','Prospectus ID','required');
		$this->form_validation->set_rules('ps_subject_id','Course Number','required|is_unique[prospectus_subjects.ps_subject_id]',
			array(
				'required'		=> 'You have not provided %s.',
				'is_unique'		=> 'This %s already exists.'
				)
			);
		$this->form_validation->set_rules('ps_year_level','Year Level','required');
		$this->form_validation->set_rules('ps_sem','Semester','required');
		
		if ($this->form_validation->run() == FALSE)
		{	
			$this->load->view('header');
			$this->load->view('admin/pros_subject');
		}
		
		else
		{
			$data['query'] = $this->Transactions_admin->p_subject();
			
			$this->session->set_flashdata('flashSuccess', 'Successfully Saved!');
			redirect('Subjects_validation/new_subject');
		
		}
	}
}