<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Menu_student extends CI_Controller{


	
	function home()
	{
		$this->load->view('header');
		$this->load->view('student/studentshome');

	}
	function student_class_schedule()
	{	
		$this->load->view('header');
		$this->load->view('student/studentshome');
		$this->load->view('student/class_schedule');
	}
	function students_grades()
	{	
		$this->load->view('header');
		$this->load->view('student/studentshome');
		$this->load->view('student/student_grades');
	}
	
	function class_subject_enrolled()
	{	
		$this->load->view('header');
		$this->load->view('student/studentshome');
		$this->load->view('student/subjects_enrolled');
	}
}