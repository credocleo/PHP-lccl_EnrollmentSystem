<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class User_validation extends CI_Controller{
	
		function __construct()
		{
			parent:: __construct();
			$this->load->view('cache');
			$this->load->helper(array('form','url','html'));
			$this->load->library('form_validation');
			$this->form_validation->set_message('alpha','Invalid Name');
			$this->form_validation->set_message('required','Require');
			
			$this->load->model('Transactions_admin');
		}
	
	function new_account($page = 'add_account')
	{
		if ( ! file_exists('application/views/admin/'.$page.'.php'))
		{
			show_404();
		}
		$this->form_validation->set_rules('account_type', 'Account Type', 'required');
			$this->form_validation->set_rules('username', 'Username', 'required|min_length[5]|max_length[12]',
				array(
				'required'		=> 'You have not provided %s.',
				'is_unique'		=> 'This %s already exists.'
				)
			);
				
		$this->form_validation->set_rules('password', 'Password', 'required|min_length[8]|max_length[20]|alpha_numeric',
			array(
				'required'		=> 'You have not provided %s.',
				'is_unique'		=> 'This %s already exists.'
				)
			);
			
		$this->form_validation->set_rules('confirm_password', 'Confirm Password', 'required|matches[password]');
		if ($this->form_validation->run() == FALSE)
		{	
			$this->load->view('header');
			$this->load->view('admin/add_account');
			$this->load->view('footer');
		}
		
		else
		{
			$data['query'] = $this->Transactions_admin->register_new_user();
			$this->session->set_flashdata('flashSuccess', 'Successfully Saved!');
			redirect('User_validation/new_account');
		}
	}
}