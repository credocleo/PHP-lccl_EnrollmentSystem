<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Student extends CI_Controller{


	public function __construct()
	{
		parent::__construct();
		if ($this->session->userdata('user_type')!="Student")
		{
			redirect('','refresh');
		}
		
	}
	public function index()
	{
		$this->load->view('header');
		$this->load->view('student/studentshome');
	}
	public function home()
	{
		$this->load->view('header');
		$this->load->view('student/studentshome');

	}
	public function student_class_schedule()
	{	
		$this->load->view('header');
		$this->load->view('student/studentshome');
		$this->load->view('student/class_schedule');
	}
	public function students_grades()
	{	
		$this->load->model('Studentmodel');
		$data["info"] = $this->Studentmodel->get_info($this->session->userdata('user'));
		$this->load->view('header');
		$this->load->view('student/studentshome');
		$this->load->view('student/student_grades', $data);
	}
	
	public function class_subject_enrolled()
	{	
		$this->load->view('header');
		$this->load->view('student/studentshome');
		$this->load->view('student/subjects_enrolled');
	}
}


