<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Subjects_validation extends CI_Controller{
	
		function __construct()
		{
			parent:: __construct();
			$this->load->view('cache');
			$this->load->helper(array('form','url','html'));
			$this->load->library('form_validation');
			$this->form_validation->set_message('alpha','Invalid Name');
			$this->form_validation->set_message('required','Require');
			
			$this->load->model('Transactions_admin');
		}
	
	function new_subject($page = 'add_subject')
	{
		if ( ! file_exists('application/views/admin/'.$page.'.php'))
		{
			show_404();
		}
		$this->form_validation->set_rules('subject_id','Subject ID','required');
		$this->form_validation->set_rules('subject_description','Description','required|is_unique[subjects.subject_description]',
			array(
				'required'		=> 'You have not provided %s.',
				'is_unique'		=> 'This %s already exists.'
				)
			);
		$this->form_validation->set_rules('subject_units','Units','required');
		$this->form_validation->set_rules('subject_lec_hours','Lecture','required');
		$this->form_validation->set_rules('subject_lab_hours','Laboratory','required');
		$this->form_validation->set_rules('subject_pre_req','Pre Requisite','required');
		
		if ($this->form_validation->run() == FALSE)
		{	
			$this->load->view('header');
			$this->load->view('admin/add_subject');
		}
		
		else
		{
			$data['query'] = $this->Transactions_admin->subjects_new();
			
			$this->session->set_flashdata('flashSuccess', 'Successfully Saved!');
			redirect('Subjects_validation/new_subject');
		
		}
	}
}