<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Admin extends CI_Controller{

	function __construct()
	{	
		parent::__construct();
		$this->load->view('cache');
		if ($this->session->userdata('user_type')!='Admin')
		{
			redirect('','refresh');
		}
	}
	function index()
	{
		$this->load->view('header');
		$this->load->view('admin/index');
	}
	function home()
	{	$this->load->view('header');
		$this->load->view('admin/index');
	}
	function add_user()
	{	$this->load->helper('form');
		$this->load->view('header');
		$this->load->view('admin/add_account');
		
	}
	
	function reg_student()
	{	$this->load->helper('form');
		$this->load->view('header');
		$this->load->view('admin/register_student');
	}
	
	function reg_teacher()
	{	$this->load->helper('form');
		$this->load->view('header');
		$this->load->view('admin/register_teacher');
	}
	
	function subject()
	{	$this->load->helper('form');
		$this->load->view('header');
		$this->load->view('admin/add_subject');
	}
	
	function prospectus()
	{	$this->load->helper('form');
		$this->load->view('header');
		$this->load->view('admin/prospectus');
	}

	function pro_subject()
	{	$this->load->helper('form');
		$this->load->view('header');
		$this->load->view('admin/pros_subject');
	}

	function courses()
	{	$this->load->helper('form');
		$this->load->view('header');
		$this->load->view('admin/courses_offered');
	}

	function search()
	{	$this->load->helper('form');
		$this->load->view('header');
		$this->load->view('admin/search');
	}

	function list_of_student()
	{	$this->load->helper('form');
		$this->load->view('header');
		$this->load->view('admin/student_list');
	}

	function form_component()
	{	$this->load->helper('form');
		$this->load->view('header');
		$this->load->view('admin/add_account');
	}	

	function prospectus_dis()
	{	$this->load->helper('form');
		$this->load->view('header');
		$this->load->view('admin/display_prospectus');
	}
}