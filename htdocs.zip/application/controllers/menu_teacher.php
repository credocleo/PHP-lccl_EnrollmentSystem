<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Menu_teacher extends CI_Controller{


	
	function home()
	{
		$this->load->view('header');
		$this->load->view('teacher/teacherhome');

	}
	function teacher_pick_subject_schedule()
	{	
		$this->load->view('header');
		$this->load->view('teacher/teacherhome');
		$this->load->view('teacher/pick_subject_schedule');
	}
	function show_subjectload()
	{	
		$this->load->view('header');
		$this->load->view('teacher/teacherhome');
		$this->load->view('teacher/show_subjectload');
	}
	
	function show_student()
	{	
		$this->load->view('header');
		$this->load->view('teacher/teacherhome');
		$this->load->view('teacher/show_student');
	}
	
	function input_grades()
	{	
		$this->load->view('header');
		$this->load->view('teacher/teacherhome');
		$this->load->view('teacher/input_grades');
	}
}