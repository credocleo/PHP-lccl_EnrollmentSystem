<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Display_prospectus extends CI_Controller{

	function __construct()
		{
			parent:: __construct();
			 $this->load->helper('url');
         	 $this->load->database();
		 }


 public function index(){

 	$this->load->model('Transactions_admin'); // load model
   $data['query'] = $this->Transactions_admin->getPosts(); // calling Post model method getPosts()
    $data['deptlist'] = $deptresult;
   $this->load->view('admin/prospectus', $data); // load the view file , we are passing $data array to view file
}
