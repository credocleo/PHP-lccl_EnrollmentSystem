<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class File_students extends CI_Controller{
	function __construct()
		{
			parent:: __construct();
			$this->load->helper(array('form','url','html'));
			$this->load->library('form_validation');
			
			$this->load->model('Transactions_admin');
		}
	
	function search()
	{
		$data['query'] = $this->Transactions_admin->get_search();
		$this->load->view('header');
		$this->load->view('admin/admin_menu');
		$this->load->view('admin/search', $data);
	}

	

}
