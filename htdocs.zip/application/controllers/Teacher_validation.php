<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Teacher_validation extends CI_Controller{
	
		function __construct()
		{
			parent:: __construct();
			$this->load->view('cache');
			$this->load->helper(array('form','url','html'));
			$this->load->library('form_validation');
			$this->form_validation->set_message('alpha','Invalid Name');
			$this->form_validation->set_message('required','Require');
			
			$this->load->model('Transactions_admin');
		}
		
	function info_teacher($page = 'register_teacher')
	{
		if ( ! file_exists('application/views/admin/'.$page.'.php'))
		{
			show_404();
		}
		$this->form_validation->set_rules('teacher_id_num', 'ID Number', 'required|is_unique[teachers.teacher_id_num]',
			array(
			'required'		=> 'You have not provided %s.',
			'is_unique'		=> 'This %s already exists.'
			)
		);
				
		$this->form_validation->set_rules('t_last_name', 'Last Name', 'required');
		$this->form_validation->set_rules('t_first_name', 'First Name', 'required');
		$this->form_validation->set_rules('t_middle_name', 'Middle Name', 'required');
		$this->form_validation->set_rules('t_date_of_birth', 'Date of Birth', 'required');
		$this->form_validation->set_rules('t_place_of_birth', 'Place of Birth', 'required');
		$this->form_validation->set_rules('t_home_address', 'Home Address', 'required');
		$this->form_validation->set_rules('t_home_tellno', 'Home tell number', 'required');
		$this->form_validation->set_rules('t_city_address', 'City Address', 'required');
		$this->form_validation->set_rules('t_cell_no', 'Cell Number', 'required');
		$this->form_validation->set_rules('t_boarding_address', 'Boarding Address', 'required');
		$this->form_validation->set_rules('t_boarding_cel_no', 'Cell Number','required');
		$this->form_validation->set_rules('t_provincial_address', 'Provincial Address', 'required');
		$this->form_validation->set_rules('t_provincial_tel_no', 'Tell Number', 'required');
		$this->form_validation->set_rules('t_nationality', 'Nationality', 'required');
		$this->form_validation->set_rules('t_religion', 'Religion', 'required');
		$this->form_validation->set_rules('t_civil_status', 'Civil Status', 'required');
		$this->form_validation->set_rules('t_email_address', 'Email Address', 'required');
		$this->form_validation->set_rules('t_gender', 'Gender', 'required');
		if ($this->form_validation->run() == FALSE)
		{
			$this->load->view('header');
			$this->load->view('admin/register_teacher');
		}
		
		else
		{
			$data['query'] = $this->Transactions_admin->teacher_info();
			$this->session->set_flashdata('flashSuccess', 'Successfully Saved!');
			redirect('Teacher_validation/info_teacher');
		}
	}
}