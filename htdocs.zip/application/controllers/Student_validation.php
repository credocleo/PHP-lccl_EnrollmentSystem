<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Student_validation extends CI_Controller{
	
		function __construct()
		{
			parent:: __construct();
			$this->load->view('cache');
			$this->load->helper(array('form','url','html'));
			$this->load->library('form_validation');
			$this->form_validation->set_message('alpha','Invalid Name');
			$this->form_validation->set_message('required','Require');
			
			$this->load->model('Transactions_admin');
		}
	
	function information_student($page = 'register_student')
	{
		if ( ! file_exists('application/views/admin/'.$page.'.php'))
		{
			show_404();
		}
		$this->form_validation->set_rules('student_id_number', 'Student ID Number', 'required|is_unique[students.student_id_number]',
			array(
			'required'		=> 'You have not provided %s.',
			'is_unique'		=> 'This %s already exists.'
			)
		);
		
		$this->form_validation->set_rules('student_last_name', 'Last Name', 'required');
		$this->form_validation->set_rules('student_first_name', 'First Name', 'required');
		$this->form_validation->set_rules('middle_name', 'Middle Name', 'required');
		$this->form_validation->set_rules('course', 'Course', 'required');
		$this->form_validation->set_rules('prospectus_course', 'Course', 'required');
		$this->form_validation->set_rules('date_of_birth', 'Date of Birth', 'required');
		$this->form_validation->set_rules('place_of_birth', 'Place of Birth', 'required');
		$this->form_validation->set_rules('contact_no','Contact No.','required');
		$this->form_validation->set_rules('home_address', 'Home Address', 'required');
		$this->form_validation->set_rules('home_tellno', 'Home Telephone Number', 'required');
		$this->form_validation->set_rules('city_address', 'City Address', 'required');
		$this->form_validation->set_rules('cell_no', 'Cell Number', 'required');
		$this->form_validation->set_rules('boarding_address', 'Boarding Address', 'required');
		$this->form_validation->set_rules('boarding_cel_no', 'Boarding Cellphone Number', 'required');
		$this->form_validation->set_rules('provincial_address', 'Provincial Address', 'required');
		$this->form_validation->set_rules('provincial_tel_no', 'Provincial Telephone Number', 'required');
		$this->form_validation->set_rules('email_address', 'Email Address', 'required');
		$this->form_validation->set_rules('nationality', 'Nationality', 'required');
		$this->form_validation->set_rules('religion', 'Religion', 'required');
		$this->form_validation->set_rules('civil_status', 'Civil Status', 'required');
		$this->form_validation->set_rules('gender', 'Gender', 'required');
		$this->form_validation->set_rules('name_of_spouse_if_married', 'Name of Spouse if Married', 'required');
		$this->form_validation->set_rules('name_of_employer_if_working', 'Name of Employer if Working', 'required');
		$this->form_validation->set_rules('employer_address', 'Employer Address', 'required');
		$this->form_validation->set_rules('employer_cel_no', 'Employer Cellphone Number', 'required');
		$this->form_validation->set_rules('fathers_name', 'Fathers Name', 'required');
		$this->form_validation->set_rules('fathers_occupation', 'Fathers Occupation', 'required');
		$this->form_validation->set_rules('father_educ_attainment', 'Father Educational Attainment', 'required');
		$this->form_validation->set_rules('mothers_name', 'Mothers Name', 'required');
		$this->form_validation->set_rules('mothers_occupation', 'Mothers Occupation', 'required');
		$this->form_validation->set_rules('mother_educ_attainment', 'Mother Educational Attainment', 'required');
		$this->form_validation->set_rules('guardians_name', 'Guardians Name', 'required');
		$this->form_validation->set_rules('guardian_occupation', 'Guardian Occupation', 'required');
		$this->form_validation->set_rules('guardians_address', 'Guardians Address', 'required');
		$this->form_validation->set_rules('guardians_cel_no', 'Guardians Cellphone Number', 'required');
		$this->form_validation->set_rules('guardian_educ_attainment', 'Guardian Educational Attainment', 'required');
		$this->form_validation->set_rules('guardian_relationship', 'Guardian Relationship', 'required');
		$this->form_validation->set_rules('grades_to_be_sent_to', 'Grades to be sent to', 'required');
		$this->form_validation->set_rules('grades_to_sent_address', 'Grades to be sent Address', 'required');
		$this->form_validation->set_rules('grades_cel_no', 'Grades to be sent to Cell Number', 'required');
		$this->form_validation->set_rules('elementary', 'Elementary', 'required');
		$this->form_validation->set_rules('elementary_sy', 'Elementary SY', 'required');
		$this->form_validation->set_rules('elementary_address', 'Elementary Address', 'required');
		$this->form_validation->set_rules('high_school', 'High School', 'required');
		$this->form_validation->set_rules('high_school_sy', 'High School SY', 'required');
		$this->form_validation->set_rules('high_school_address', 'High School Address', 'required');
		$this->form_validation->set_rules('college', 'College', 'required');
		$this->form_validation->set_rules('college_sy', 'College SY', 'required');
		$this->form_validation->set_rules('college_address', 'College Address', 'required');
		if ($this->form_validation->run() == FALSE)
		{
			$this->load->view('header');
			$this->load->view('admin/register_student');
		}
		
		else
		{
			$data['query'] = $this->Transactions_admin->student_add();
			$this->session->set_flashdata('flashSuccess', 'Successfully Saved!');
			redirect('Student_validation/information_student');
		}
	}
}