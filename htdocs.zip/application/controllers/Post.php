<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Post extends CI_Controller{

	function __construct()
	{	
		parent::__construct();
		$this->load->view('cache');
		$this->load->model('Transactions_admin');
	}

	function index()
	{
		$query = $this->Transactions_admin->getProspectus();
		$data['PROSPECTUS'] = null;
		if($query){
			$data['PROSPECTUS'] = $query;
		}

		$this->load->view('admin/display_prospectus', $data);
	}