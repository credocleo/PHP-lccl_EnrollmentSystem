<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Prospectus_validation extends CI_Controller{
	
		function __construct()
		{
			parent:: __construct();
			$this->load->view('cache');
			$this->load->helper(array('form','url','html'));
			$this->load->library('form_validation');
			$this->form_validation->set_message('alpha','Invalid Name');
			$this->form_validation->set_message('required','Require');
			
			$this->load->model('Transactions_admin');
		}
	
	function prospectus($page = 'prospectus')
	{
		if ( ! file_exists('application/views/admin/'.$page.'.php'))
		{
			show_404();
		}
		$this->form_validation->set_rules('per_cmo', 'Curriculum Year', 'required');
		
		$this->form_validation->set_rules('major_in', 'Major In', 'required|is_unique[prospectus.major_in]',
			array(
			'required'		=> 'You have not provided %s.',
			'is_unique'		=> 'This %s already exists.'
			)
		);
		$this->form_validation->set_rules('prospectus_course', 'Prospectus Course', 'required');
		$this->form_validation->set_rules('prospectus_sy', 'Prospectus School Year', 'required');
		
		
		if ($this->form_validation->run() == FALSE)
		{
			$this->load->view('header');
			$this->load->view('admin/prospectus');
		}
		
		else
		{
			$data['query'] = $this->Transactions_admin->prospectus();
			$this->session->set_flashdata('flashSuccess', 'Successfully Saved!');
			redirect('Prospectus_validation/prospectus');
		}
		
	}
}